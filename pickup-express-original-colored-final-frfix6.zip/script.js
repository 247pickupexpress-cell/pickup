
(function(){
  const T = {
    en: {
      "#seo .section__head h2": "Moving, Junk Removal & Delivery Services in Montréal & Laval",
      "#seo .seo-p-1": "Pickup Express is a trusted local company for affordable and reliable moving, junk removal, delivery, and cleaning services across Greater Montréal. From small condo moves in Plateau‑Mont‑Royal to same‑day junk pickup in Laval and fast deliveries to the West Island, our trained team brings the trucks, tools, and care to get it done right.",
      "#seo .seo-p-2": "We help families, students, property managers, and businesses save time and money with clear pricing and insured service. Our bilingual movers and haulers handle furniture removal, appliance recycling, post‑renovation cleanup, and careful item protection — always with friendly service and on‑time arrivals.",
      "#seo .seo-p-3": "If you searched for “Montréal junk removal”, “Laval movers”, “West Island delivery”, “Montreal moving company”, “appliance removal Montréal”, “eco‑friendly junk pickup” — you’re in the right place. Get a fast quote and book today.",
      "#seo .seo__list h3": "Top Services We Rank For",
      "#seo .seo__cta": "Serving Montréal, Laval, West Island & nearby — request a quick quote.",

      "#service-area .section__head h2": "Service Area",
      "#service-area .service-lead": "We serve Montréal, Laval, West Island & nearby areas — same great service everywhere.",
      "#service-area .area__cta": "If you’re nearby, we likely serve you — ask for a quick quote.",

      ".menu a[href='#services']": "Services",
      ".menu a[href='#why']": "Why Us",
      ".menu a[href='#gallery']": "Gallery",
      ".menu a[href='#quote']": "Get a Quote",
      ".hero__subtitle": "Moving • Junk Removal • Delivery • Cleaning — Same-day options. Fair prices. 5-star crew.",
      "#services .section__head h2": "Our Services",
      "#services .section__head p": "Full-service help for homes, condos, and businesses across Greater Montréal.",
      "#why .section__head h2": "Why Choose Pickup Express",
      "#why .section__head p": "We show up on time, treat your space like our own, and finish the job right the first time.",
      "#gallery .section__head h2": "Project Gallery",
      "#gallery .section__head p": "Recent moves, cleanups, and deliveries from our team.",
      "#quote .quote__copy h2": "Get Your Fast, Free Quote",
      "#quote .quote__copy p": "Tell us about your job. We’ll reply quickly with options and pricing.",
      "#quote .bullets li:nth-child(1)": "10% off weekday morning bookings",
      "#quote .bullets li:nth-child(2)": "No hidden fees — ever",
      "#quote .bullets li:nth-child(3)": "We recycle & donate whenever possible",
      ".form .row:nth-of-type(1) label:nth-of-type(1) span": "Full Name",
      ".form .row:nth-of-type(1) label:nth-of-type(2) span": "Phone",
      ".form .row:nth-of-type(2) label:nth-of-type(1) span": "Email",
      ".form .row:nth-of-type(2) label:nth-of-type(2) span": "Service",
      ".form .row:nth-of-type(3) label:nth-of-type(1) span": "Preferred Date",
      ".form .row:nth-of-type(3) label:nth-of-type(2) span": "Preferred Time",
      ".form > label span": "Details (addresses, items, stairs, photos link)",
      ".check span": "I agree to be contacted about my request.",
      ".form button[type='submit']": "Send Request",
      ".form__foot a": "Prefer to call? Tap here.",
      ".footer h4:nth-of-type(1)": "Contact",
      ".footer h4:nth-of-type(2)": "Links",
      ".footer .foot-list li:nth-child(3)": "Montréal, QC",
      ".footer .foot-list li:nth-child(4)": "Hours: 7am–9pm, 7 days"
    },
    fr: {
      "#seo .section__head h2": "Services de déménagement, débarras et livraison à Montréal et Laval",
      "#seo .seo-p-1": "Pickup Express est une entreprise locale de confiance pour des services abordables et fiables de déménagement, débarras, livraison et nettoyage dans le Grand Montréal. Des petits déménagements de condos à Plateau‑Mont‑Royal aux débarras le jour même à Laval et aux livraisons rapides vers l’Ouest‑de‑l’Île, notre équipe formée a les camions, les outils et le soin nécessaires pour bien faire le travail.",
      "#seo .seo-p-2": "Nous aidons familles, étudiants, gestionnaires immobiliers et entreprises à gagner du temps et de l’argent grâce à des prix clairs et un service assuré. Nos déménageurs et débarrasseurs bilingues s’occupent de l’enlèvement de meubles, du recyclage des électroménagers, du nettoyage après rénovation et de la protection soignée des items — toujours avec un service courtois et ponctuel.",
      "#seo .seo-p-3": "Si vous avez cherché « débarras Montréal », « déménageurs Laval », « livraison Ouest‑de‑l’Île », « entreprise de déménagement Montréal », « enlèvement d’électros Montréal », « débarras écoresponsable » — vous êtes au bon endroit. Obtenez un devis rapide et réservez dès aujourd’hui.",
      "#seo .seo__list h3": "Principaux services pour lesquels nous nous positionnons",
      "#seo .seo__cta": "Montréal, Laval, Ouest‑de‑l’Île et environs — demandez un devis rapide.",

      "#service-area .section__head h2": "Secteurs desservis",
      "#service-area .service-lead": "Nous desservons Montréal, Laval, West Island et environs — le même excellent service partout.",
      "#service-area .area__cta": "Si vous êtes à proximité, nous vous desservons probablement — demandez un devis rapide.",

      ".menu a[href='#services']": "Services",
      ".menu a[href='#why']": "Pourquoi nous",
      ".menu a[href='#gallery']": "Galerie",
      ".menu a[href='#quote']": "Obtenir un devis",
      ".hero__subtitle": "Déménagement • Débarras • Livraison • Nettoyage — Service le jour même. Prix justes. Équipe 5 étoiles.",
      "#services .section__head h2": "Nos services",
      "#services .section__head p": "Service complet pour maisons, condos et entreprises dans le Grand Montréal.",
      "#why .section__head h2": "Pourquoi choisir Pickup Express",
      "#why .section__head p": "Nous arrivons à l’heure, respectons votre espace et faisons bien le travail du premier coup.",
      "#gallery .section__head h2": "Galerie de projets",
      "#gallery .section__head p": "Déménagements, nettoyages et livraisons récents par notre équipe.",
      "#quote .quote__copy h2": "Obtenez un devis rapide et gratuit",
      "#quote .quote__copy p": "Décrivez votre demande. Nous répondrons rapidement avec des options et des prix.",
      "#quote .bullets li:nth-child(1)": "10 % de rabais le matin en semaine",
      "#quote .bullets li:nth-child(2)": "Aucuns frais cachés — jamais",
      "#quote .bullets li:nth-child(3)": "Nous recyclons et faisons des dons lorsque possible",
      ".form .row:nth-of-type(1) label:nth-of-type(1) span": "Nom complet",
      ".form .row:nth-of-type(1) label:nth-of-type(2) span": "Téléphone",
      ".form .row:nth-of-type(2) label:nth-of-type(1) span": "Courriel",
      ".form .row:nth-of-type(2) label:nth-of-type(2) span": "Service",
      ".form .row:nth-of-type(3) label:nth-of-type(1) span": "Date souhaitée",
      ".form .row:nth-of-type(3) label:nth-of-type(2) span": "Heure souhaitée",
      ".form > label span": "Détails (adresses, items, escaliers, lien photos)",
      ".check span": "J’accepte d’être contacté au sujet de ma demande.",
      ".form button[type='submit']": "Envoyer la demande",
      ".form__foot a": "Vous préférez appeler ? Cliquez ici.",
      ".footer h4:nth-of-type(1)": "Contact",
      ".footer h4:nth-of-type(2)": "Liens",
      ".footer .foot-list li:nth-child(3)": "Montréal (QC)",
      ".footer .foot-list li:nth-child(4)": "Heures : 7h–21h, 7 jours"
    }
  };

  function setText(sel, text){
    const el = document.querySelector(sel);
    if(el){ el.textContent = text; }
  }

  function applyLang(lang){
    document.documentElement.lang=lang;
    localStorage.setItem('site_lang',lang);
    const map=T[lang];
    Object.keys(map).forEach(sel=>setText(sel,map[sel]));

    // Switch service descriptions using data attributes
    document.querySelectorAll('.svc').forEach(el=>{
      el.textContent = el.getAttribute(lang==='fr' ? 'data-fr' : 'data-en');
    });

    // Thank-you bilingual block
    document.querySelectorAll('#thankyou [data-lang]').forEach(el=>{
      el.style.display = (el.getAttribute('data-lang')===lang)?'block':'none';
    });

    // Press state on buttons
    document.querySelectorAll('.lang__btn').forEach(btn=>{
      btn.setAttribute('aria-pressed', btn.getAttribute('data-lang')===lang);
    });
  }

  document.querySelectorAll('.lang__btn').forEach(btn=>{
    btn.addEventListener('click',()=>applyLang(btn.getAttribute('data-lang')));
  });
  applyLang(localStorage.getItem('site_lang')||'en');

  // Quote form -> show thank-you
  const form=document.getElementById('quoteForm');
  const thank=document.getElementById('thankyou');
  if(form){
    form.addEventListener('submit',()=>{
      setTimeout(()=>{
        form.style.display='none';
        if(thank){ thank.style.display='block'; }
        applyLang(localStorage.getItem('site_lang')||'en');
      },400);
    });
  }
})();